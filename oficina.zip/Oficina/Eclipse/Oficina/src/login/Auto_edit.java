package login;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableModel;

import net.proteanit.sql.DbUtils;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Auto_edit extends JFrame {

	private JPanel contentPane;
	private JTextField ano;
	private JTextField marca;
	private JTextField modelo;
	private JTextField cor;
	private JTextField matricula;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Auto_edit frame = new Auto_edit();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Auto_edit() {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowActivated(WindowEvent e) {
				try {            		

                    Class.forName("com.mysql.jdbc.Driver");

                    Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/oficina","root","");

                    Statement stmt=con.createStatement();

                    String sql="Select * from automoveis";

                    ResultSet rs=stmt.executeQuery(sql);

                    table.setModel(DbUtils.resultSetToTableModel(rs));

                    table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

                    System.out.println("Carregar dados para a tabela");

                    con.close();

                    }

				catch(Exception ee){

                    	System.out.println(ee);

                    	}
			}
		});
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 405);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Ano");
		lblNewLabel.setBounds(10, 67, 46, 14);
		contentPane.add(lblNewLabel);
		
		ano = new JTextField();
		ano.setColumns(10);
		ano.setBounds(10, 92, 125, 27);
		contentPane.add(ano);
		
		JLabel lblntelefone = new JLabel("Marca");
		lblntelefone.setBounds(10, 130, 46, 14);
		contentPane.add(lblntelefone);
		
		marca = new JTextField();
		marca.setColumns(10);
		marca.setBounds(10, 155, 125, 27);
		contentPane.add(marca);
		
		JLabel lblMorada = new JLabel("Modelo");
		lblMorada.setBounds(10, 193, 46, 14);
		contentPane.add(lblMorada);
		
		modelo = new JTextField();
		modelo.setColumns(10);
		modelo.setBounds(10, 218, 125, 27);
		contentPane.add(modelo);
		
		JLabel lblNif = new JLabel("Cor");
		lblNif.setBounds(10, 256, 46, 14);
		contentPane.add(lblNif);
		
		cor = new JTextField();
		cor.setColumns(10);
		cor.setBounds(10, 281, 125, 27);
		contentPane.add(cor);
		
		JButton btnEditar = new JButton("Editar");
		btnEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (JOptionPane.showConfirmDialog(null, "Pretende Editar este registo?", "Aten��o!", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {

					try {

						

					    String sql="UPDATE automoveis SET matricula='"+matricula.getText()+"', ano='"+ano.getText()+"', marca='"+marca.getText()+"', modelo='"+modelo.getText()+"', cor='"+cor.getText()+"' WHERE matricula='"+matricula.getText()+"'";;

						

					    Class.forName("com.mysql.jdbc.Driver");

						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oficina","root","");

						Statement stmt=con.createStatement();	

						int ok=stmt.executeUpdate(sql);

							System.out.println("Foi Editado " + ok +  " linha na BD");

						}catch (Exception ex1) {

							

							System.out.println(ex1);



						}

				}	
			}
		});
		btnEditar.setBounds(10, 318, 125, 40);
		contentPane.add(btnEditar);
		
		JLabel lblNewLabel_1 = new JLabel("Matr\u00EDcula");
		lblNewLabel_1.setBounds(10, 10, 45, 13);
		contentPane.add(lblNewLabel_1);
		
		matricula = new JTextField();
		matricula.setBounds(10, 33, 125, 27);
		contentPane.add(matricula);
		matricula.setColumns(10);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int index=table.getSelectedRow();

			    TableModel row=table.getModel();

			  

			    matricula.setText(row.getValueAt(index, 0).toString());

			    

			    ano.setText(row.getValueAt(index, 1).toString());

			   

			    marca.setText(row.getValueAt(index, 2).toString());

			   
			    
			    modelo.setText(row.getValueAt(index, 3).toString());
			    
			    
			    
			    cor.setText(row.getValueAt(index,  4).toString());
			
			}
		});
		table.setBounds(145, 9, 281, 349);
		contentPane.add(table);
	}
}