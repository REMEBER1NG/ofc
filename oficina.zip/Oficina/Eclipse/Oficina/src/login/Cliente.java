package login;



import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.table.TableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;





public class Cliente extends JFrame {

	private JPanel contentPane;
	private JTextField nome;
	private JTextField nif;
	private JTextField nntelefone;
	private final JScrollPane scrollPane = new JScrollPane();
	private JTable table;
	String id;
	private JTextField morada;
	private JTextField ncliente;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cliente frame = new Cliente();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Cliente() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 786, 470);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(217, 11, 493, 279);
		contentPane.add(scrollPane);
		
		nome = new JTextField();
		nome.setBounds(24, 84, 125, 27);
		contentPane.add(nome);
		nome.setColumns(10);
		
		nif = new JTextField();
		nif.setColumns(10);
		nif.setBounds(24, 263, 125, 27);
		contentPane.add(nif);
		
		nntelefone = new JTextField();
		nntelefone.setColumns(10);
		nntelefone.setBounds(24, 145, 125, 27);
		contentPane.add(nntelefone);
		
		JLabel lblNewLabel = new JLabel("Nome");
		lblNewLabel.setBounds(24, 59, 46, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNif = new JLabel("NIF");
		lblNif.setBounds(24, 240, 46, 14);
		contentPane.add(lblNif);
		
		JLabel lblntelefone = new JLabel("Telefone");
		lblntelefone.setBounds(24, 126, 46, 14);
		contentPane.add(lblntelefone);
		
		JButton btnNewButton = new JButton("Editar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (JOptionPane.showConfirmDialog(null, "Pretende Editar este registo?", "Aten��o!", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {

					try {

					    String sql="UPDATE clientes SET nome='"+nome.getText()+"', nif='"+nif.getText()+"', nntelefone='"+nntelefone.getText()+"',morada='"+morada.getText()+"', WHERE ncliente='"+ncliente+"'";;

					    Class.forName("com.mysql.jdbc.Driver");

						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oficina","root","");

						Statement stmt=con.createStatement();	

						int ok=stmt.executeUpdate(sql);

						System.out.println("Foi Editado " + ok +  " linha na BD");
						
						nome.setText("");
						nif.setText("");
						nntelefone.setText("");
						morada.setText("");
						ncliente.setText("");
							
						}catch (Exception ex1) {

							System.out.println(ex1);
						}
				}
			}
		});
		btnNewButton.setBounds(217, 324, 136, 40);
		contentPane.add(btnNewButton);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {

				    String sql="Insert into clientes (ncliente,nome, nif, nntelefone,morada) Values ('"+nome.getText()+"', '"+nif.getText()+"','"+nntelefone.getText()+"','"+morada.getText()+"',)";

				    Class.forName("com.mysql.jdbc.Driver");

					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oficina","root","");

					Statement stmt=con.createStatement();	

					int ok=stmt.executeUpdate(sql);

					System.out.println("inseridas " + ok +  " linhas na BD");
					
					nome.setText("");
					nif.setText("");
					nntelefone.setText("");
					morada.setText("");
					ncliente.setText("");

				}catch (Exception ex1) {

						System.out.println(ex1);

				}
			}
		});
		btnRegistrar.setBounds(406, 324, 125, 40);
		contentPane.add(btnRegistrar);
		
		JButton btnApagar = new JButton("Apagar");
		btnApagar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (JOptionPane.showConfirmDialog(null, "Pretende apagar este registo?", "Aten��o!", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {

					try {

					    String sql="DELETE FROM clientes WHERE ncliente='"+ncliente+"'";;

					    Class.forName("com.mysql.jdbc.Driver");

						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oficina","root","");

						Statement stmt=con.createStatement();	

						int ok=stmt.executeUpdate(sql);

						System.out.println("Foi apagado " + ok +  " linha na BD");
						
						nome.setText("");
						nif.setText("");
						nntelefone.setText("");
						morada.setText("");
						ncliente.setText("");
						
						}catch (Exception ex1) {

							System.out.println(ex1);
						}
				}
				
			}
		});
		btnApagar.setBounds(585, 324, 125, 40);
		contentPane.add(btnApagar);
		
		JButton btnCarregarInformaes = new JButton("Carregar Informa\u00E7\u00F5es");
		btnCarregarInformaes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				try {            		

                    Class.forName("com.mysql.jdbc.Driver");

                    Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/oficina","root","");

                    Statement stmt=con.createStatement();

                    String sql="Select * from clientes";

                    ResultSet rs=stmt.executeQuery(sql);

                    table.setModel(DbUtils.resultSetToTableModel(rs));

                    table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

                    System.out.println("Carregar dados para a tabela");

                    con.close();

                    }

				catch(Exception ee){

                    	System.out.println(ee);

                }
			}
		});
		btnCarregarInformaes.setBounds(24, 324, 139, 40);
		contentPane.add(btnCarregarInformaes);
		
		JLabel lblMorada = new JLabel("Morada");
		lblMorada.setBounds(24, 183, 46, 14);
		contentPane.add(lblMorada);
		
		morada = new JTextField();
		morada.setColumns(10);
		morada.setBounds(24, 202, 125, 27);
		contentPane.add(morada);
		
		ncliente = new JTextField();
		ncliente.setEditable(false);
		ncliente.setColumns(10);
		ncliente.setBounds(82, 11, 67, 27);
		contentPane.add(ncliente);
		
		JLabel lblId = new JLabel("Id");
		lblId.setBounds(24, 17, 46, 14);
		contentPane.add(lblId);
	}
}
