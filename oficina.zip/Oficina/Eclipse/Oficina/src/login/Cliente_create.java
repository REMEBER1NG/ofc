package login;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Cliente_create extends JFrame {

	private JPanel contentPane;
	private JTextField nome;
	private JTextField ntelefone;
	private JTextField morada;
	private JTextField nif;
	private JTextField matricula;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cliente_create frame = new Cliente_create();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Cliente_create() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 440);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Nome");
		lblNewLabel.setBounds(151, 10, 46, 14);
		contentPane.add(lblNewLabel);
		
		nome = new JTextField();
		nome.setColumns(10);
		nome.setBounds(151, 35, 125, 27);
		contentPane.add(nome);
		
		JLabel lblntelefone = new JLabel("Telefone");
		lblntelefone.setBounds(151, 73, 46, 14);
		contentPane.add(lblntelefone);
		
		ntelefone = new JTextField();
		ntelefone.setColumns(10);
		ntelefone.setBounds(151, 98, 125, 27);
		contentPane.add(ntelefone);
		
		JLabel lblMorada = new JLabel("Morada");
		lblMorada.setBounds(151, 136, 46, 14);
		contentPane.add(lblMorada);
		
		morada = new JTextField();
		morada.setColumns(10);
		morada.setBounds(151, 161, 125, 27);
		contentPane.add(morada);
		
		JLabel lblNif = new JLabel("NIF");
		lblNif.setBounds(151, 199, 46, 14);
		contentPane.add(lblNif);
		
		nif = new JTextField();
		nif.setColumns(10);
		nif.setBounds(151, 224, 125, 27);
		contentPane.add(nif);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
try {

					

				    String sql="Insert into clientes (nome,ntelefone,morada,nif, matricula) Values ('"+nome.getText()+"', '"+ntelefone.getText()+"', '"+morada.getText()+"', '"+nif.getText()+"', '"+matricula.getText()+"')";

					

				    Class.forName("com.mysql.jdbc.Driver");

					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oficina","root","");

					Statement stmt=con.createStatement();	

					int ok=stmt.executeUpdate(sql);

						System.out.println("Inseridas " + ok +  " linhas na BD");

					}catch (Exception ex1) {

						

						System.out.println(ex1);



					}


			}
		});
		btnRegistrar.setBounds(151, 336, 125, 40);
		contentPane.add(btnRegistrar);
		
		JLabel lblNewLabel_1 = new JLabel("Matr\u00EDcula");
		lblNewLabel_1.setBounds(151, 261, 45, 13);
		contentPane.add(lblNewLabel_1);
		
		matricula = new JTextField();
		matricula.setBounds(151, 284, 125, 27);
		contentPane.add(matricula);
		matricula.setColumns(10);
	}
}