package login;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableModel;

import net.proteanit.sql.DbUtils;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Reparacoes_edit extends JFrame {

	private JPanel contentPane;
	private JTextField nfunc;
	private JTextField kms;
	private JTextField matricula;
	private JTextField nrep;
	private JTextField data;
	private JTable table;
	private JLabel lblNewLabel_2;
	private JTextField tipo;
	private JLabel lblNewLabel_3;
	private JTextField valor;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Reparacoes_edit frame = new Reparacoes_edit();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Reparacoes_edit() {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowActivated(WindowEvent e) {
				try {            		

                    Class.forName("com.mysql.jdbc.Driver");

                    Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/oficina","root","");

                    Statement stmt=con.createStatement();

                    String sql="Select * from reparacoes";

                    ResultSet rs=stmt.executeQuery(sql);

                    table.setModel(DbUtils.resultSetToTableModel(rs));

                    table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

                    System.out.println("Carregar dados para a tabela");

                    con.close();

                    }

				catch(Exception ee){

                    	System.out.println(ee);

                    	}
			}
		});
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 531);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("N\u00BA Funcionario");
		lblNewLabel.setBounds(10, 67, 125, 14);
		contentPane.add(lblNewLabel);
		
		nfunc = new JTextField();
		nfunc.setColumns(10);
		nfunc.setBounds(10, 92, 125, 27);
		contentPane.add(nfunc);
		
		JLabel lblntelefone = new JLabel("Quil\u00F3metros");
		lblntelefone.setBounds(10, 130, 125, 14);
		contentPane.add(lblntelefone);
		
		kms = new JTextField();
		kms.setColumns(10);
		kms.setBounds(10, 155, 125, 27);
		contentPane.add(kms);
		
		JLabel lblMorada = new JLabel("Matr\u00EDcula");
		lblMorada.setBounds(10, 193, 125, 14);
		contentPane.add(lblMorada);
		
		matricula = new JTextField();
		matricula.setColumns(10);
		matricula.setBounds(10, 218, 125, 27);
		contentPane.add(matricula);
		
		JLabel lblNif = new JLabel("N\u00BA Repara\u00E7\u00E3o");
		lblNif.setBounds(10, 256, 125, 14);
		contentPane.add(lblNif);
		
		nrep = new JTextField();
		nrep.setEditable(false);
		nrep.setColumns(10);
		nrep.setBounds(10, 281, 125, 27);
		contentPane.add(nrep);
		
		JButton btnEditar = new JButton("Editar");
		btnEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (JOptionPane.showConfirmDialog(null, "Pretende Editar este registo?", "Aten��o!", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {

					try {

						

					    String sql="UPDATE reparacoes SET data='"+data.getText()+"', nfunc='"+nfunc.getText()+"', kms='"+kms.getText()+"', matricula='"+matricula.getText()+"', nrep='"+nrep.getText()+"', tipo='"+tipo.getText()+"', valor='"+valor.getText()+"' WHERE matricula='"+matricula.getText()+"'";;

						

					    Class.forName("com.mysql.jdbc.Driver");

						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oficina","root","");

						Statement stmt=con.createStatement();	

						int ok=stmt.executeUpdate(sql);

							System.out.println("Foi Editado " + ok +  " linha na BD");

						}catch (Exception ex1) {

							

							System.out.println(ex1);



						}

				}	
			}
		});
		btnEditar.setBounds(10, 454, 125, 40);
		contentPane.add(btnEditar);
		
		JLabel lblNewLabel_1 = new JLabel("Data");
		lblNewLabel_1.setBounds(10, 10, 45, 13);
		contentPane.add(lblNewLabel_1);
		
		data = new JTextField();
		data.setBounds(10, 33, 125, 27);
		contentPane.add(data);
		data.setColumns(10);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int index=table.getSelectedRow();

			    TableModel row=table.getModel();

			  

			    data.setText(row.getValueAt(index, 0).toString());

			    

			    nfunc.setText(row.getValueAt(index, 1).toString());

			   

			    kms.setText(row.getValueAt(index, 2).toString());

			   
			    
			    matricula.setText(row.getValueAt(index, 3).toString());
			    
			    
			    
			    nrep.setText(row.getValueAt(index,  4).toString());
			    
			    
			    
			    tipo.setText(row.getValueAt(index, 5).toString());
			    
			    
			    
			    valor.setText(row.getValueAt(index, 6).toString());
			
			}
		});
		table.setBounds(145, 9, 281, 485);
		contentPane.add(table);
		
		lblNewLabel_2 = new JLabel("Tipo");
		lblNewLabel_2.setBounds(11, 318, 124, 13);
		contentPane.add(lblNewLabel_2);
		
		tipo = new JTextField();
		tipo.setBounds(10, 341, 125, 27);
		contentPane.add(tipo);
		tipo.setColumns(10);
		
		lblNewLabel_3 = new JLabel("Valor");
		lblNewLabel_3.setBounds(11, 378, 124, 13);
		contentPane.add(lblNewLabel_3);
		
		valor = new JTextField();
		valor.setBounds(10, 401, 125, 27);
		contentPane.add(valor);
		valor.setColumns(10);
	}
}