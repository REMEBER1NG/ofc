package login;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Func_create extends JFrame {

	private JPanel contentPane;
	private JTextField nome;
	private JTextField morada;
	private JTextField nss;
	private JTextField nib;
	private JTextField nfunc;
	private JTextField password;
	private JTextField tipo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Func_create frame = new Func_create();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Func_create() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 331, 440);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Nome");
		lblNewLabel.setBounds(10, 67, 46, 14);
		contentPane.add(lblNewLabel);
		
		nome = new JTextField();
		nome.setColumns(10);
		nome.setBounds(10, 92, 125, 27);
		contentPane.add(nome);
		
		JLabel lblntelefone = new JLabel("Morada");
		lblntelefone.setBounds(10, 130, 46, 14);
		contentPane.add(lblntelefone);
		
		morada = new JTextField();
		morada.setColumns(10);
		morada.setBounds(10, 155, 125, 27);
		contentPane.add(morada);
		
		JLabel lblMorada = new JLabel("N\u00BA Seg. Social");
		lblMorada.setBounds(10, 193, 125, 14);
		contentPane.add(lblMorada);
		
		nss = new JTextField();
		nss.setColumns(10);
		nss.setBounds(10, 218, 125, 27);
		contentPane.add(nss);
		
		JLabel lblNif = new JLabel("NIB");
		lblNif.setBounds(10, 255, 125, 14);
		contentPane.add(lblNif);
		
		nib = new JTextField();
		nib.setColumns(10);
		nib.setBounds(10, 281, 125, 27);
		contentPane.add(nib);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
try {

					

				    String sql="Insert into funcionario (nfunc,nome,morada,nss,nib,password,tipo) Values ('"+nfunc.getText()+"', '"+nome.getText()+"', '"+morada.getText()+"', '"+nss.getText()+"', '"+nib.getText()+"', '"+password.getText()+"', '"+tipo.getText()+"')";

					

				    Class.forName("com.mysql.jdbc.Driver");

					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oficina","root","");

					Statement stmt=con.createStatement();	

					int ok=stmt.executeUpdate(sql);

						System.out.println("Inseridas " + ok +  " linhas na BD");

					}catch (Exception ex1) {

						

						System.out.println(ex1);



					}


			}
		});
		btnRegistrar.setBounds(10, 333, 250, 40);
		contentPane.add(btnRegistrar);
		
		nfunc = new JTextField();
		nfunc.setBounds(10, 30, 125, 27);
		contentPane.add(nfunc);
		nfunc.setColumns(10);
		
		JLabel lblNewLabel1 = new JLabel("N\u00FAmero Funcion\u00E1rio");
		lblNewLabel1.setBounds(10, 10, 125, 13);
		contentPane.add(lblNewLabel1);
		
		JLabel lblNewLabel_1 = new JLabel("Password");
		lblNewLabel_1.setBounds(145, 10, 45, 13);
		contentPane.add(lblNewLabel_1);
		
		password = new JTextField();
		password.setBounds(145, 30, 125, 27);
		contentPane.add(password);
		password.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Tipo");
		lblNewLabel_2.setBounds(145, 68, 45, 13);
		contentPane.add(lblNewLabel_2);
		
		tipo = new JTextField();
		tipo.setBounds(145, 92, 125, 27);
		contentPane.add(tipo);
		tipo.setColumns(10);
	}
}