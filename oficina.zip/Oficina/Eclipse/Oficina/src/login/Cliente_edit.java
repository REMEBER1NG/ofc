package login;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableModel;

import net.proteanit.sql.DbUtils;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Cliente_edit extends JFrame {

	private JPanel contentPane;
	private JTextField nome;
	private JTextField ntelefone;
	private JTextField morada;
	private JTextField nif;
	private JTextField ncliente;
	private JTable table;
	private JLabel lblNewLabel_2;
	private JTextField matricula;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cliente_edit frame = new Cliente_edit();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Cliente_edit() {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowActivated(WindowEvent e) {
				try {            		

                    Class.forName("com.mysql.jdbc.Driver");

                    Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/oficina","root","");

                    Statement stmt=con.createStatement();

                    String sql="Select * from clientes";

                    ResultSet rs=stmt.executeQuery(sql);

                    table.setModel(DbUtils.resultSetToTableModel(rs));

                    table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

                    System.out.println("Carregar dados para a tabela");

                    con.close();

                    }

				catch(Exception ee){

                    	System.out.println(ee);

                    	}
			}
		});
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 476);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Nome");
		lblNewLabel.setBounds(10, 67, 46, 14);
		contentPane.add(lblNewLabel);
		
		nome = new JTextField();
		nome.setColumns(10);
		nome.setBounds(10, 92, 125, 27);
		contentPane.add(nome);
		
		JLabel lblntelefone = new JLabel("Telefone");
		lblntelefone.setBounds(10, 130, 46, 14);
		contentPane.add(lblntelefone);
		
		ntelefone = new JTextField();
		ntelefone.setColumns(10);
		ntelefone.setBounds(10, 155, 125, 27);
		contentPane.add(ntelefone);
		
		JLabel lblMorada = new JLabel("Morada");
		lblMorada.setBounds(10, 193, 46, 14);
		contentPane.add(lblMorada);
		
		morada = new JTextField();
		morada.setColumns(10);
		morada.setBounds(10, 218, 125, 27);
		contentPane.add(morada);
		
		JLabel lblNif = new JLabel("NIF");
		lblNif.setBounds(10, 256, 46, 14);
		contentPane.add(lblNif);
		
		nif = new JTextField();
		nif.setColumns(10);
		nif.setBounds(10, 281, 125, 27);
		contentPane.add(nif);
		
		JButton btnEditar = new JButton("Editar");
		btnEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (JOptionPane.showConfirmDialog(null, "Pretende Editar este registo?", "Aten��o!", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {

					try {

						

					    String sql="UPDATE clientes SET nome='"+nome.getText()+"', ntelefone='"+ntelefone.getText()+"', morada='"+morada.getText()+"', ntelefone='"+ntelefone.getText()+"' WHERE ncliente='"+ncliente.getText()+"'";;

						

					    Class.forName("com.mysql.jdbc.Driver");

						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oficina","root","");

						Statement stmt=con.createStatement();	

						int ok=stmt.executeUpdate(sql);

							System.out.println("Foi Editado " + ok +  " linha na BD");

						}catch (Exception ex1) {

							

							System.out.println(ex1);



						}

				}	
			}
		});
		btnEditar.setBounds(10, 389, 125, 40);
		contentPane.add(btnEditar);
		
		JLabel lblNewLabel_1 = new JLabel("ID");
		lblNewLabel_1.setBounds(10, 10, 45, 13);
		contentPane.add(lblNewLabel_1);
		
		ncliente = new JTextField();
		ncliente.setEditable(false);
		ncliente.setBounds(10, 33, 125, 27);
		contentPane.add(ncliente);
		ncliente.setColumns(10);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int index=table.getSelectedRow();

			    TableModel row=table.getModel();

			  

			    ncliente.setText(row.getValueAt(index, 0).toString());

			    

			    nome.setText(row.getValueAt(index, 1).toString());

			   

			    ntelefone.setText(row.getValueAt(index, 2).toString());

			   
			    
			    morada.setText(row.getValueAt(index, 3).toString());
			    
			    
			    
			    nif.setText(row.getValueAt(index,  4).toString());
			    
			    
			    
			    matricula.setText(row.getValueAt(index, 5).toString());
			
			}
		});
		table.setBounds(145, 9, 281, 420);
		contentPane.add(table);
		
		lblNewLabel_2 = new JLabel("Matr\u00EDcula");
		lblNewLabel_2.setBounds(10, 318, 45, 13);
		contentPane.add(lblNewLabel_2);
		
		matricula = new JTextField();
		matricula.setBounds(10, 341, 125, 27);
		contentPane.add(matricula);
		matricula.setColumns(10);
	}
}