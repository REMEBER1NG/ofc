package login;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Reparacoes_create extends JFrame {

	private JPanel contentPane;
	private JTextField nfunc;
	private JTextField kms;
	private JTextField matricula;
	private JTextField nrep;
	private JTextField data;
	private JTextField tipo;
	private JTextField valor;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Reparacoes_create frame = new Reparacoes_create();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Reparacoes_create() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 531);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("N\u00BA Funcionario");
		lblNewLabel.setBounds(151, 67, 125, 14);
		contentPane.add(lblNewLabel);
		
		nfunc = new JTextField();
		nfunc.setColumns(10);
		nfunc.setBounds(151, 92, 125, 27);
		contentPane.add(nfunc);
		
		JLabel lblntelefone = new JLabel("Quil\u00F3metros");
		lblntelefone.setBounds(151, 130, 125, 14);
		contentPane.add(lblntelefone);
		
		kms = new JTextField();
		kms.setColumns(10);
		kms.setBounds(151, 155, 125, 27);
		contentPane.add(kms);
		
		JLabel lblMorada = new JLabel("Matr\u00EDcula");
		lblMorada.setBounds(151, 193, 125, 14);
		contentPane.add(lblMorada);
		
		matricula = new JTextField();
		matricula.setColumns(10);
		matricula.setBounds(151, 218, 125, 27);
		contentPane.add(matricula);
		
		JLabel lblNif = new JLabel("N\u00BA Repara\u00E7\u00E3o");
		lblNif.setBounds(151, 255, 125, 14);
		contentPane.add(lblNif);
		
		nrep = new JTextField();
		nrep.setColumns(10);
		nrep.setBounds(151, 281, 125, 27);
		contentPane.add(nrep);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
try {

					

				    String sql="Insert into reparações (data,nfunc,kms,matricula,tipo,valor) Values ('"+data.getText()+"', '"+nfunc.getText()+"', '"+kms.getText()+"', '"+matricula.getText()+"', '"+tipo.getText()+"', '"+valor.getText()+"')";

					

				    Class.forName("com.mysql.jdbc.Driver");

					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oficina","root","");

					Statement stmt=con.createStatement();	

					int ok=stmt.executeUpdate(sql);

						System.out.println("Inseridas " + ok +  " linhas na BD");

					}catch (Exception ex1) {

						

						System.out.println(ex1);



					}


			}
		});
		btnRegistrar.setBounds(151, 445, 125, 40);
		contentPane.add(btnRegistrar);
		
		data = new JTextField();
		data.setBounds(151, 30, 125, 27);
		contentPane.add(data);
		data.setColumns(10);
		
		JLabel lblNewLabel1 = new JLabel("Data");
		lblNewLabel1.setBounds(151, 10, 45, 13);
		contentPane.add(lblNewLabel1);
		
		JLabel lblNewLabel_1 = new JLabel("Tipo");
		lblNewLabel_1.setBounds(152, 318, 124, 13);
		contentPane.add(lblNewLabel_1);
		
		tipo = new JTextField();
		tipo.setBounds(151, 341, 125, 27);
		contentPane.add(tipo);
		tipo.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Valor");
		lblNewLabel_2.setBounds(152, 378, 124, 13);
		contentPane.add(lblNewLabel_2);
		
		valor = new JTextField();
		valor.setBounds(151, 401, 125, 27);
		contentPane.add(valor);
		valor.setColumns(10);
	}
}