package login;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableModel;

import net.proteanit.sql.DbUtils;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Func_edit extends JFrame {

	private JPanel contentPane;
	private JTextField nome;
	private JTextField morada;
	private JTextField nss;
	private JTextField nib;
	private JTextField nfunc;
	private JTable table;
	private JLabel lblNewLabel_2;
	private JTextField password;
	private JLabel lblNewLabel_3;
	private JTextField tipo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Func_edit frame = new Func_edit();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Func_edit() {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowActivated(WindowEvent e) {
				try {            		

                    Class.forName("com.mysql.jdbc.Driver");

                    Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/oficina","root","");

                    Statement stmt=con.createStatement();

                    String sql="Select * from funcionarios";

                    ResultSet rs=stmt.executeQuery(sql);

                    table.setModel(DbUtils.resultSetToTableModel(rs));

                    table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

                    System.out.println("Carregar dados para a tabela");

                    con.close();

                    }

				catch(Exception ee){

                    	System.out.println(ee);

                    	}
			}
		});
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 518);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Nome");
		lblNewLabel.setBounds(10, 67, 125, 14);
		contentPane.add(lblNewLabel);
		
		nome = new JTextField();
		nome.setColumns(10);
		nome.setBounds(10, 92, 125, 27);
		contentPane.add(nome);
		
		JLabel lblntelefone = new JLabel("Morada");
		lblntelefone.setBounds(10, 130, 125, 14);
		contentPane.add(lblntelefone);
		
		morada = new JTextField();
		morada.setColumns(10);
		morada.setBounds(10, 155, 125, 27);
		contentPane.add(morada);
		
		JLabel lblMorada = new JLabel("N\u00BA Seg. Social");
		lblMorada.setBounds(10, 193, 125, 14);
		contentPane.add(lblMorada);
		
		nss = new JTextField();
		nss.setColumns(10);
		nss.setBounds(10, 218, 125, 27);
		contentPane.add(nss);
		
		JLabel lblNif = new JLabel("NIB");
		lblNif.setBounds(10, 256, 125, 14);
		contentPane.add(lblNif);
		
		nib = new JTextField();
		nib.setColumns(10);
		nib.setBounds(10, 281, 125, 27);
		contentPane.add(nib);
		
		JButton btnEditar = new JButton("Editar");
		btnEditar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (JOptionPane.showConfirmDialog(null, "Pretende Editar este registo?", "Aten��o!", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {

					try {

						

					    String sql="UPDATE funcionarios SET nfunc='"+nfunc.getText()+"', nome='"+nome.getText()+"', morada='"+morada.getText()+"', nss='"+nss.getText()+"', nib='"+nib.getText()+"', password='"+password.getText()+"', tipo='"+tipo.getText()+"' WHERE nfunc='"+nfunc.getText()+"'";;

						

					    Class.forName("com.mysql.jdbc.Driver");

						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oficina","root","");

						Statement stmt=con.createStatement();	

						int ok=stmt.executeUpdate(sql);

							System.out.println("Foi Editado " + ok +  " linha na BD");

						}catch (Exception ex1) {

							

							System.out.println(ex1);



						}

				}	
			}
		});
		btnEditar.setBounds(10, 438, 125, 40);
		contentPane.add(btnEditar);
		
		JLabel lblNewLabel_1 = new JLabel("N\u00BA Funcion\u00E1rio");
		lblNewLabel_1.setBounds(10, 10, 125, 13);
		contentPane.add(lblNewLabel_1);
		
		nfunc = new JTextField();
		nfunc.setBounds(10, 33, 125, 27);
		contentPane.add(nfunc);
		nfunc.setColumns(10);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int index=table.getSelectedRow();

			    TableModel row=table.getModel();

			  

			    nfunc.setText(row.getValueAt(index, 0).toString());

			    

			    nome.setText(row.getValueAt(index, 1).toString());

			   

			    morada.setText(row.getValueAt(index, 2).toString());

			   
			    
			    nss.setText(row.getValueAt(index, 3).toString());
			    
			    
			    
			    nib.setText(row.getValueAt(index,  4).toString());
			    
			    
			    
			    password.setText(row.getValueAt(index, 5).toString());
			    
			    
			    
			    tipo.setText(row.getValueAt(index, 6).toString());
			
			}
		});
		table.setBounds(145, 9, 281, 469);
		contentPane.add(table);
		
		lblNewLabel_2 = new JLabel("Password");
		lblNewLabel_2.setBounds(11, 318, 124, 13);
		contentPane.add(lblNewLabel_2);
		
		password = new JTextField();
		password.setBounds(10, 341, 125, 27);
		contentPane.add(password);
		password.setColumns(10);
		
		lblNewLabel_3 = new JLabel("Tipo");
		lblNewLabel_3.setBounds(11, 378, 124, 13);
		contentPane.add(lblNewLabel_3);
		
		tipo = new JTextField();
		tipo.setBounds(10, 401, 125, 27);
		contentPane.add(tipo);
		tipo.setColumns(10);
	}
}