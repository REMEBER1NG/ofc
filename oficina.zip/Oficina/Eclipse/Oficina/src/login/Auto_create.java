package login;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class Auto_create extends JFrame {

	private JPanel contentPane;
	private JTextField ano;
	private JTextField marca;
	private JTextField modelo;
	private JTextField cor;
	private JTextField matricula;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Auto_create frame = new Auto_create();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Auto_create() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 440);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Ano");
		lblNewLabel.setBounds(151, 67, 46, 14);
		contentPane.add(lblNewLabel);
		
		ano = new JTextField();
		ano.setColumns(10);
		ano.setBounds(151, 92, 125, 27);
		contentPane.add(ano);
		
		JLabel lblntelefone = new JLabel("Marca");
		lblntelefone.setBounds(151, 130, 46, 14);
		contentPane.add(lblntelefone);
		
		marca = new JTextField();
		marca.setColumns(10);
		marca.setBounds(151, 155, 125, 27);
		contentPane.add(marca);
		
		JLabel lblMorada = new JLabel("Modelo");
		lblMorada.setBounds(151, 193, 46, 14);
		contentPane.add(lblMorada);
		
		modelo = new JTextField();
		modelo.setColumns(10);
		modelo.setBounds(151, 218, 125, 27);
		contentPane.add(modelo);
		
		JLabel lblNif = new JLabel("Cor");
		lblNif.setBounds(151, 255, 46, 14);
		contentPane.add(lblNif);
		
		cor = new JTextField();
		cor.setColumns(10);
		cor.setBounds(151, 281, 125, 27);
		contentPane.add(cor);
		
		JButton btnRegistrar = new JButton("Registrar");
		btnRegistrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
try {

					

				    String sql="Insert into automoveis (matricula,ano,marca,modelo,cor) Values ('"+matricula.getText()+"', '"+ano.getText()+"', '"+marca.getText()+"', '"+modelo.getText()+"', '"+cor.getText()+"')";

					

				    Class.forName("com.mysql.jdbc.Driver");

					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/oficina","root","");

					Statement stmt=con.createStatement();	

					int ok=stmt.executeUpdate(sql);

						System.out.println("Inseridas " + ok +  " linhas na BD");

					}catch (Exception ex1) {

						

						System.out.println(ex1);



					}


			}
		});
		btnRegistrar.setBounds(151, 331, 125, 40);
		contentPane.add(btnRegistrar);
		
		matricula = new JTextField();
		matricula.setBounds(151, 30, 125, 27);
		contentPane.add(matricula);
		matricula.setColumns(10);
		
		JLabel lblNewLabel1 = new JLabel("Matr\u00EDcula");
		lblNewLabel1.setBounds(151, 10, 45, 13);
		contentPane.add(lblNewLabel1);
	}
}