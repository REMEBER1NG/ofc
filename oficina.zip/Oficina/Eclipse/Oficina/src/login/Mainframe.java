package login;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Mainframe extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Mainframe frame = new Mainframe();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Mainframe() {
		setTitle("Oficina Michelle");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 455, 488);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\120479\\Desktop\\l\\a.png"));
		lblNewLabel.setBounds(0, 0, 439, 222);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Adicionar Cliente");
		lblNewLabel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Cliente_create Cliente_create = new Cliente_create();
				Cliente_create.setVisible(true);
			}
		});
		lblNewLabel_1.setBounds(28, 276, 126, 19);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Editar Cliente");
		lblNewLabel_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Cliente_edit Cliente_edit = new Cliente_edit();
				Cliente_edit.setVisible(true);
			}
		});
		lblNewLabel_2.setBounds(207, 279, 145, 19);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Adicionar Autom\u00F3vel");
		lblNewLabel_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Auto_create Auto_create = new Auto_create();
				Auto_create.setVisible(true);
			}
		});
		lblNewLabel_3.setBounds(28, 323, 139, 13);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Editar Autom\u00F3vel");
		lblNewLabel_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Auto_edit Auto_edit = new Auto_edit();
				Auto_edit.setVisible(true);
			}
		});
		lblNewLabel_4.setBounds(207, 323, 187, 13);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Adicionar Funcionario");
		lblNewLabel_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Func_create Func_create = new Func_create();
				Func_create.setVisible(true);
			}
		});
		lblNewLabel_5.setBounds(28, 361, 139, 13);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("Editar Funcionario");
		lblNewLabel_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Func_edit Func_edit = new Func_edit();
				Func_edit.setVisible(true);
			}
		});
		lblNewLabel_6.setBounds(207, 361, 208, 13);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Nova Repara\u00E7\u00E3o");
		lblNewLabel_7.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Reparacoes_create Reparacoes_create = new Reparacoes_create();
				Reparacoes_create.setVisible(true);
			}
		});
		lblNewLabel_7.setBounds(28, 399, 126, 13);
		contentPane.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("Consultar Repara\u00E7\u00F5es");
		lblNewLabel_8.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Reparacoes_edit Reparacoes_edit = new Reparacoes_edit();
				Reparacoes_edit.setVisible(true);
			}
		});
		lblNewLabel_8.setBounds(207, 399, 145, 13);
		contentPane.add(lblNewLabel_8);
	}

}
